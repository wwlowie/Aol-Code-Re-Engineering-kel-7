public void calc_print(int type, int side, int width) {
    int area = 0;
    if (shapetype == "square") {
        area = side * side;
    } else if (shapetype == "rectangle") {
        area = side * width;
    } else if (shapetype == "circle") {
        area = 3.14 * side * side;
    }

    System.out.println("Area of " + shapetype + " : " + area);
}

class Main {
    public static void main(String[] args) {
        int squareSide = 7;
        int rectangleWidth = 8;
        int rectangleHeight = 3;
        int circleRadius = 10;

        calc_print("square", squareSide, 0);
        calc_print("rectangle", rectangleWidth, rectangleHeight);
        calc_print("circle", circleRadius, 0);
    }
}
