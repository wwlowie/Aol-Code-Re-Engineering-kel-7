public class Main {
    public static void main(String[] args) throws Exception {
        
        Employee employee1 = new Employee("John","Male",26,10000,60);
        Display.displayEmployees(employee1);
    }
}
