
class Main {
	public static void main(String[] args) {
	sedan partSedan = new sedan();
	partSedan.type();
	partSedan.parkingSensor();
	partSedan.turbo();
	partSedan.headLamps();
	}
}
