public enum QrImgFormat{
    png
}
